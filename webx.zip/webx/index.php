<?php
    
$showAlert = false;
$showError = false;
$exists=false;
    
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Include file which makes the
    // Database Connection.
    include 'connection.php';
    
    $email = $_POST["email"];
    $sql = "Select * from email where email='$email'";
    
    $result = mysqli_query($conn, $sql);
    
    $num = mysqli_num_rows($result);
    
    $sql = "INSERT INTO `email` ( `email`, `date`) VALUES ('$email', current_timestamp())";
    
    $result = mysqli_query($conn, $sql);
    }
    
?>

<!DOCTYPE html>
<html lang="en" class="no-js" >
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WebX Developers</title>

    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- favicons
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">

    <!-- Social Media Icon Pack -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

    <!-- Our Service Icon -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <!-- Google Font -->
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap"
      rel="stylesheet"
    />

</head>

<body id="top">


    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>


    <!-- page wrap
    ================================================== -->
    <div id="page" class="s-pagewrap">


        <!-- # site header 
        ================================================== -->
        <header class="s-header">

            <div class="row s-header__inner">
                <div class="column lg-12 s-header__block">

                    <div class="s-header__logo">
                        <a class="logo" href="index.html">
                            <img src="images/logo.png" alt="Homepage">
                        </a>
                    </div>

                    <ul class="s-header__social">

                        <li>
                            <a href="https://www.instagram.com/webx_creation" name="Instagram">
                                <ion-icon  name="logo-instagram"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="#0" name="Linked-in">
                                <ion-icon  name="logo-linkedin"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="https://www.facebook.com/profile.php?id=100093162650483" name="Facebook">
                                <ion-icon  name="logo-facebook"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="https://twitter.com/Webx_Dev" name="Twitter">
                                <ion-icon  name="logo-twitter"></ion-icon>
                            </a>
                        </li>

                    </ul> <!-- end s-header__social -->
                    
                </div> <!-- end s-header__block -->
            </div> <!-- end s-header__inner -->

        </header> <!-- end s-header -->


        <!-- # intro
        ================================================== -->
        <section id="intro" class="s-intro">

            <div class="s-intro__bg"></div>

            <div class="row s-intro__content">
                <div class="column lg-12">

                    <div class="s-intro__content-top">
                        <h1>
                        Something great is going to come. Stay tuned!!
                        </h1>
                        <p class="">
                        Boosts your business with our expert web development services. Get noticed and stay ahead of the competition.
                        </p>
                    </div> <!-- end s-intro__content-top --> 

                    <div class="s-intro__content-sep">
                        <span></span>
                        <span>COMING SOON</span>
                        <span></span>
                    </div> <!-- end s-intro__content-sep --> 
                    
                    <div class="s-intro__content-counter counter">
                        <div class="counter__time">
                            <span class="ss-days">365</span>
                            <span>Days</span>
                        </div>
                        <div class="counter__time">
                            <span class="ss-hours">03</span>
                            <span>Hours</span>
                        </div>
                        <div class="counter__time minutes">
                            <span class="ss-minutes">01</span>
                            <span>Mins</span>
                        </div>
                        <div class="counter__time">
                            <span class="ss-seconds">55</span>
                            <span>Secs</span>
                        </div>
                    </div> <!-- end counter --> 
                    
                    <div class="s-intro__content-subscribe">
                        <form action="index.php" method="post">
                            
                            <input type="text" name="email">
                            <button type="submit">Submit</button>
    
                            </form>
                    </div> <!-- end s-intro__content-subscribe -->     

                </div>    
            </div> <!-- intro__content -->

            <div class="s-intro__scroll-down">
                <a href="#about" class="smoothscroll">
                    <span>Scroll Down</span>
                </a>
            </div> <!-- s-intro__scroll-down -->

        </section> <!-- end s-intro -->


        <!-- # about
        ================================================== -->
        <section id="about" class="s-about">

            <div class="row section-header">
                <div class="column lg-12 ss-animate ss-fade-up">
                    <h1 class="text-display-title">
                        About Us.
                    </h1>
                    <p class="lead">
                        "Welcome to WebX!"<br> 
                        At WebX, we are a passionate group of developers dedicated to creating innovative and high-quality solutions for our clients. With a combined experience of 2 years in the industry, we have honured our skills and expertise to deliver exceptional web development, marketing and brand strategy services.
                    </p>
                </div>
            </div> <!-- end section-header -->

            <div class="row process-list">
    
                <div class="column lg-12 list-block">
                    <div class="list-block__item ss-animate ss-fade-up">
                        <div class="list-block__title">
                            <div class="list-block__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" version="1.1">
                                    <path d="M 183.593 2.464 C 180.344 3.806, 176.069 6.196, 174.093 7.775 C 169.327 11.582, 163.392 20.457, 162.036 25.802 C 161.301 28.701, 160.973 50.485, 161.030 92.633 L 161.115 155.162 119.454 246.994 L 77.793 338.826 52.646 339.170 L 27.500 339.514 21.278 342.381 C 13.969 345.749, 5.971 353.655, 2.694 360.749 C 0.521 365.454, 0.500 366.018, 0.500 419.500 L 0.500 473.500 3.081 479.002 C 6.380 486.034, 13.966 493.620, 20.998 496.919 L 26.500 499.500 78 499.797 C 130.621 500.101, 134.059 499.907, 141.442 496.219 C 147.084 493.402, 154.641 485.190, 157.546 478.722 C 160.008 473.241, 160.396 470.982, 160.803 459.750 L 161.265 447 250 447 L 338.735 447 339.197 459.750 C 339.604 470.982, 339.992 473.241, 342.454 478.722 C 345.735 486.028, 353.577 493.994, 360.749 497.306 C 365.454 499.479, 366.018 499.500, 419.500 499.500 L 473.500 499.500 479.002 496.919 C 482.029 495.499, 486.710 492.132, 489.406 489.436 C 494.130 484.712, 498.970 476.316, 498.990 472.809 C 498.996 471.879, 499.450 470.840, 500 470.500 C 500.646 470.101, 501 451.637, 501 418.382 C 501 387.345, 500.635 367.108, 500.081 367.450 C 499.576 367.762, 498.847 366.551, 498.461 364.759 C 496.654 356.370, 488.145 346.723, 478.722 342.381 L 472.500 339.514 447.359 339.170 L 422.218 338.826 380.580 247.081 L 338.943 155.337 338.721 90.418 L 338.500 25.500 336 20.500 C 332.592 13.685, 325.143 6.426, 318.236 3.188 L 312.500 0.500 251 0.262 L 189.500 0.024 183.593 2.464 M 197 89.500 L 197 143 250 143 L 303 143 303 89.500 L 303 36 250 36 L 197 36 197 89.500 M 154.042 258 C 134.215 301.725, 117.994 337.771, 117.996 338.102 C 117.998 338.433, 121.650 338.985, 126.110 339.329 C 140.562 340.443, 151.117 347.400, 157.250 359.854 L 160.500 366.453 160.846 388.727 L 161.193 411 250 411 L 338.807 411 339.154 388.727 L 339.500 366.453 342.750 359.854 C 348.883 347.400, 359.438 340.443, 373.890 339.329 C 378.350 338.985, 382.001 338.433, 382.001 338.102 C 382.002 337.771, 365.778 301.725, 345.949 258 L 309.895 178.500 249.994 178.500 L 190.092 178.500 154.042 258 M 0.465 419.500 C 0.465 448.100, 0.593 459.656, 0.749 445.180 C 0.906 430.704, 0.906 407.304, 0.749 393.180 C 0.593 379.056, 0.465 390.900, 0.465 419.500 M 36 419.508 L 36 464 80.500 464 L 125 464 125 419.546 L 125 375.092 80.500 375.054 L 36 375.017 36 419.508 M 375 419.546 L 375 464 419.500 464 L 464 464 464 419.508 L 464 375.017 419.500 375.054 L 375 375.092 375 419.546" stroke="none" fill="currentColor" fill-rule="evenodd"></path>
                                </svg>
                            </div>
                            <h3 class="h5">Our Process</h3>
                        </div>
                        <div class="list-block__text">
                            <p>
                                Our process as a web developers can vary depending on the project and the specific development methodology. Starts by Requirement Gathering, followed by Planning and Design for Web/App, after that Front-End and Back-End Development, then after Content Creation, after that Testing and Debugging, after that Deployment, and Launching it and Promoting it, and finally maintenance.
                            </p>
                        </div>
                    </div> <!-- end list-block__item -->
                    
                    <div class="list-block__item ss-animate ss-fade-up">
                        <div class="list-block__title">
                            <div class="list-block__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" version="1.1">
                                    <path d="M 240 0.625 C 238.625 0.891, 235.250 1.820, 232.500 2.689 C 226.736 4.511, 23.276 99.195, 17.994 102.514 C 4.743 110.841, -2.158 129.625, 2.344 145.111 C 4.373 152.090, 10.266 160.493, 16 164.583 C 23.036 169.603, 227.166 263.817, 235.910 266.081 C 245.318 268.517, 254.670 268.519, 264.090 266.086 C 268.982 264.823, 305.350 248.370, 371.126 217.663 C 425.920 192.083, 473.545 169.744, 476.960 168.020 C 485.549 163.685, 491.399 157.967, 495.250 150.144 C 498.261 144.027, 498.500 142.806, 498.500 133.521 C 498.500 124.704, 498.173 122.802, 495.778 117.691 C 494.202 114.328, 490.798 109.677, 487.691 106.643 C 482.570 101.644, 477.569 99.201, 378.133 53.138 C 320.827 26.592, 271.366 3.965, 268.220 2.857 C 262.567 0.866, 245.660 -0.471, 240 0.625 M 243.922 36.656 C 243.054 36.890, 196.254 58.586, 139.922 84.870 C 78.020 113.754, 37.386 133.251, 37.211 134.152 C 37 135.239, 64.976 148.662, 140.211 183.572 C 243.069 231.300, 243.527 231.500, 250 231.500 C 256.484 231.500, 256.756 231.380, 359.500 183.353 C 434.307 148.384, 462.500 134.760, 462.500 133.577 C 462.500 132.391, 435.015 119.215, 361.500 85.158 C 305.950 59.424, 258.970 37.836, 257.101 37.184 C 253.824 36.043, 247.193 35.777, 243.922 36.656 M 9.229 245.942 C 7.430 247.072, 4.618 250.110, 2.979 252.694 C 0.495 256.610, -0 258.427, -0 263.619 C -0 271.259, 2.429 274.677, 10.883 278.934 C 31.260 289.192, 232.115 381.316, 236.718 382.515 C 243.966 384.403, 254.982 384.416, 262.164 382.546 C 266.672 381.371, 472.239 287.500, 489.893 278.554 C 492.591 277.187, 496.193 274.376, 497.899 272.307 C 500.656 268.961, 501 267.831, 501 262.105 C 501 258.564, 500.712 255.955, 500.359 256.307 C 500.007 256.660, 498.441 254.934, 496.880 252.472 C 495.319 250.010, 492.570 247.072, 490.771 245.942 C 483.873 241.611, 486.474 240.565, 365.198 296.473 C 257.456 346.142, 252.705 348.224, 248.198 347.739 C 244.761 347.369, 213.836 333.470, 133 295.966 C 13.587 240.563, 16.148 241.598, 9.229 245.942 M 0.328 263.500 C 0.333 267.350, 0.513 268.802, 0.730 266.728 C 0.946 264.653, 0.943 261.503, 0.722 259.728 C 0.501 257.952, 0.324 259.650, 0.328 263.500 M 9.229 362.002 C 7.430 363.098, 4.618 366.110, 2.979 368.694 C 0.495 372.610, -0 374.427, -0 379.619 C -0 387.454, 2.426 390.681, 11.886 395.435 C 33.806 406.451, 231.676 497.202, 236.529 498.466 C 244.018 500.416, 254.936 500.428, 262.361 498.494 C 267.174 497.241, 467.097 405.965, 488.143 395.413 C 491.921 393.519, 496.127 390.457, 497.893 388.313 C 500.657 384.960, 501 383.833, 501 378.105 C 501 374.564, 500.712 371.955, 500.359 372.307 C 500.007 372.660, 498.441 370.934, 496.880 368.472 C 493.442 363.051, 488.757 360.009, 483.839 360.004 C 479.083 359.999, 481.656 358.854, 360 415.091 C 258.997 461.780, 255.299 463.397, 249.500 463.408 C 243.676 463.419, 240.472 462.012, 140.500 415.572 C 83.850 389.255, 33.540 365.986, 28.700 363.862 C 18.784 359.510, 14.056 359.058, 9.229 362.002 M 0.328 379.500 C 0.333 383.350, 0.513 384.802, 0.730 382.728 C 0.946 380.653, 0.943 377.503, 0.722 375.728 C 0.501 373.952, 0.324 375.650, 0.328 379.500" stroke="none" fill="#000000" fill-rule="evenodd"></path>
                                </svg>
                            </div>
                            <h3 class="h5">Our Approach</h3>
                        </div>
                        <div class="list-block__text">
                            <p>
                                As a web developer, we need to enhance our skills and stay up-to-date with the latest trends and technologies in the field.We'll build a strong foundation to Understand responsive web design principles to create websites that work well on different devices and screen sizes.Expand our Knowledge in a fields like front-end framework, back-end technologies, Database and get familiar with APIs.
                            </p>
                        </div>
                    </div> <!-- end list-block__item -->
                    
                    <div class="list-block__item ss-animate ss-fade-up">
                        <div class="list-block__title">
                            <div class="list-block__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" version="1.1">
                                    <path d="M 162.692 1.182 C 161.148 1.745, 126.062 10.020, 84.724 19.570 C 35.211 31.010, 8.720 37.565, 7.093 38.780 C 5.735 39.794, 3.696 41.866, 2.562 43.385 L 0.500 46.147 0.228 265.823 C -0.075 509.887, -0.606 490.627, 6.600 496.953 C 9.549 499.543, 10.878 500, 15.461 500 C 18.891 500, 48.477 493.623, 96.753 482.479 L 172.652 464.957 244.291 481.490 C 283.692 490.583, 317.100 498.468, 318.530 499.011 C 321.857 500.276, 333.102 500.292, 336.403 499.037 C 337.797 498.507, 371.239 490.617, 410.718 481.504 C 450.198 472.391, 484.815 464.276, 487.644 463.470 C 492.922 461.968, 498.768 456.786, 499.214 453.215 C 499.332 452.272, 499.700 459.375, 500.032 469 C 500.364 478.625, 500.600 380.300, 500.557 250.500 C 500.481 23.533, 500.407 14.338, 498.635 10.263 C 497.622 7.932, 495.249 4.670, 493.362 3.013 C 490.453 0.459, 489.109 0, 484.539 0 C 481.109 0, 451.531 6.375, 403.274 17.515 L 327.402 35.031 255.771 18.517 C 216.375 9.435, 182.955 1.553, 181.505 1.002 C 178.153 -0.273, 166.372 -0.160, 162.692 1.182 M 96 53.931 C 66.025 60.919, 40.263 66.952, 38.750 67.337 L 36 68.038 36 263.519 C 36 419.257, 36.254 458.992, 37.250 458.962 C 37.938 458.941, 64.375 452.936, 96 445.618 L 153.500 432.312 153.753 236.656 C 153.992 50.744, 153.918 41.006, 152.253 41.112 C 151.289 41.174, 125.975 46.942, 96 53.931 M 191.247 236.624 L 191.500 432.248 249.497 445.624 C 281.395 452.981, 307.834 459, 308.250 459 C 308.665 459, 308.891 370.969, 308.753 263.376 L 308.500 67.752 250.503 54.376 C 218.605 47.019, 192.166 41, 191.750 41 C 191.335 41, 191.109 129.031, 191.247 236.624 M 403.500 54.438 L 346.500 67.684 346.247 263.342 C 346.109 370.954, 346.347 459, 346.778 459 C 347.678 459, 459.599 433.223, 462.250 432.405 C 463.909 431.893, 464 421.687, 464 236.433 C 464 50.936, 463.911 41.005, 462.250 41.096 C 461.288 41.149, 434.850 47.153, 403.500 54.438 M 0.491 267.500 C 0.491 388.500, 0.608 437.852, 0.750 377.170 C 0.892 316.489, 0.892 217.489, 0.750 157.170 C 0.608 96.852, 0.491 146.500, 0.491 267.500" stroke="none" fill="currentColor" fill-rule="evenodd"></path>
                                </svg>
                            </div>
                            <h3 class="h5">Our Vision</h3>
                        </div>
                        <div class="list-block__text">
                            <p>
                                The vision of WebX encompasses the future direction and potential advancements in the field.WebX will explore AR(Augmented Reality) and VR(Virtual Reality),AI(Artificial intelligence) and ML(Machine learning) technologies, creating immersive web experiences and interactive content.
                            </p>
                        </div>
                    </div> <!-- end list-block__item -->
                    
                    <div class="list-block__item ss-animate ss-fade-up">
                        <div class="list-block__title">
                            <div class="list-block__icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" version="1.1">
                                    <path d="M 79.467 1.998 C 77.250 3.096, 74.550 5.458, 73.467 7.247 C 71.525 10.458, 71.500 13.588, 71.500 249.500 C 71.500 486.702, 71.515 488.526, 73.500 491.895 C 76.810 497.516, 80.213 499.395, 87.782 499.782 C 93.297 500.064, 95.293 499.712, 98.926 497.813 C 107.634 493.262, 107 501.948, 107 387.266 L 107 286 259.750 285.994 C 359.953 285.991, 413.756 285.640, 416.152 284.974 C 421.074 283.607, 427.703 276.817, 429.069 271.742 C 429.952 268.464, 429.844 266.880, 428.498 263.355 C 427.336 260.314, 412.112 241.822, 377.800 201.777 C 350.830 170.300, 328.557 144.009, 328.305 143.353 C 328.053 142.697, 350.121 116.179, 377.344 84.425 C 418.828 36.036, 427.018 25.987, 427.933 22.351 C 430.080 13.826, 426.727 5.141, 419.980 1.752 C 416.709 0.108, 406.521 0.003, 250 0.002 C 85.620 0.002, 83.449 0.027, 79.467 1.998 M 108 143 L 108 250 239.500 250 C 311.825 250, 371 249.812, 371 249.582 C 371 249.352, 352.522 227.640, 329.939 201.332 C 307.355 175.024, 288.005 151.830, 286.939 149.790 C 284.654 145.418, 284.472 141.168, 286.379 136.718 C 287.137 134.948, 305.924 112.320, 328.129 86.433 C 350.333 60.546, 369.118 38.608, 369.872 37.683 C 371.157 36.107, 362.846 36, 239.622 36 L 108 36 108 143" stroke="none" fill="currentColor" fill-rule="evenodd"></path>
                                </svg>
                            </div>
                            <h3 class="h5">Our Objective</h3>
                        </div>
                        <div class="list-block__text">
                            <p>
                                Our top most objective is to Building user-friendly websites, Implementing responsive design, Writing clean and maintainable code, Optimization of website performance, Ensuring website security, Integrating with back-end systems, and Continuous learning and staying updated in this field 
                            </p>
                        </div>
                    </div> <!-- end list-block__item -->
                
                </div> <!-- end list-block -->                
    
            </div> <!-- end process-list -->

            <div class="row cta-wrap">
                <div class="column lg-12 cta ss-animate ss-fade-up">
                    <div class="cta__content">
                
                <section>
      <div class="row">
        <h2 class="section-heading">Our Services</h2>
      </div>
      <div class="row">
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-hammer"></i>
            </div>
            <h3>Web-Designing</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-brush"></i>
            </div>
            <h3>Digital Marketing</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-wrench"></i>
            </div>
            <h3>SEO</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-truck-pickup"></i>
            </div>
            <h3>Web-Hosting</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-broom"></i>
            </div>
            <h3>Logo-Designing</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
        <div class="column">
          <div class="card">
            <div class="icon-wrapper">
              <i class="fas fa-plug"></i>
            </div>
            <h3>Brand-Strategy</h3>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
              consequatur necessitatibus eaque.
            </p>
          </div>
        </div>
      </div>
    </section>
                

                        

                    
                    </div>
                </div> <!-- end cta -->
            </div> <!-- end cta-wrap -->

        </section> 


        


        <!-- # footer
        ================================================== -->
        <footer id="footer" class="s-footer">

            <div class="row s-footer__main">
                <div class="column s-footer__main-content">

                    <h3 class="h6">Get In Touch</h3>

                    <p class="contact-email">
                        <a href="mailto:thewebxdevelopers@gmail.com">thewebxdevelopers@gmail.com</a>   
                    </p>

                    <ul class="contact-info">                        
                        <li class="info-address">
                            Rajkot, Gujarat, India  
                        </li>

                        <li class="info-phone">
                            <a href="tel:+91972-326-9209">972-326-9209</a>  
                        </li>
                        
                    </ul>

                </div> <!-- end s-footer__main-content -->
            </div> <!-- end s-footer__main -->

            <div class="row s-footer__bottom">
                <div class="column lg-12 s-footer__bottom-content">
    
                    <p class="ss-copyright">
                        <span>© Copyright WebX 2023</span> 
                        <span>All rights reserved for WebX.</span> 
                        <span>Design by <a href="#">Web-X</a></span>
                    </p>

                    <ul class="s-footer__social">
                        <li>
                            <a href="https://www.instagram.com/webx_creation" name="Instagram">
                                <ion-icon  name="logo-instagram"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="#0" name="Linked-in">
                                <ion-icon  name="logo-linkedin"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="https://www.facebook.com/profile.php?id=100093162650483" name="Facebook">
                                <ion-icon  name="logo-facebook"></ion-icon>
                            </a>
                        </li>

                        <li>
                            <a href="https://twitter.com/Webx_Dev" name="Twitter">
                                <ion-icon  name="logo-twitter"></ion-icon>
                            </a>
                        </li>
                    </ul> <!-- end s-footer__social -->

                </div> <!-- end s-footer__bottom-content -->
            </div> <!-- end s-footer__bottom -->
            

            <div class="ss-go-top">
                <a class="smoothscroll" title="Back to Top" href="#top">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" version="1.1">
                        <path d="M 291.199 2.131 C 288.833 3.302, 286.133 5.426, 285.199 6.852 C 284.264 8.278, 259.558 33.532, 230.295 62.972 C 193.865 99.624, 176.603 117.672, 175.545 120.218 C 172.378 127.838, 174.552 135.386, 182.022 142.711 C 189.774 150.313, 197.881 152.181, 205.626 148.151 C 207.788 147.027, 224.968 130.635, 244.495 111.068 C 263.742 91.781, 279.829 76, 280.245 76 C 281.335 76, 281.145 332.354, 280.045 345.651 C 278.022 370.090, 270.240 390.839, 256.131 409.406 C 242.480 427.370, 222.118 442.102, 201 449.294 C 184 455.083, 182.157 455.257, 131 455.901 C 78.663 456.561, 80.239 456.362, 74.645 463.010 C 71.178 467.130, 69.673 473.189, 70.265 480.644 C 70.887 488.481, 73.949 494.027, 79.368 497.132 L 83.500 499.500 126.500 499.809 C 172.926 500.142, 182.387 499.567, 200.500 495.311 C 257.790 481.850, 304.942 435.391, 319.522 378.036 C 324.535 358.318, 324.351 364.069, 324.734 215.064 L 325.091 75.628 360.796 111.207 C 380.433 130.775, 398.020 147.550, 399.879 148.485 C 407.249 152.192, 416.077 149.965, 423.521 142.521 C 430.724 135.318, 432.929 126.760, 429.400 119.700 C 428.521 117.940, 404.108 92.618, 375.150 63.428 C 346.193 34.238, 321.404 8.866, 320.065 7.046 C 316.580 2.310, 310.924 0.048, 302.500 0.023 C 297.340 0.007, 294.369 0.561, 291.199 2.131" stroke="none" fill="#000000" fill-rule="evenodd"></path>
                    </svg>
                </a>
            </div> <!-- end ss-go-top -->

        </footer> <!-- end s-footer -->

    </div> <!-- end s-pagewrap -->    


    <!-- Java Script
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>